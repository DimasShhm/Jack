module.exports = {
  BOT_TOKEN: "-",
  OWNER_ID: ["-"],
};